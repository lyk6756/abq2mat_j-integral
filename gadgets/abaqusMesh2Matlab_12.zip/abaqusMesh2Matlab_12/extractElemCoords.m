function [ Ex, Ey ] = extractElemCoords( Edof, Coord, Dof )
% function [ Ex, Ey ] = extractElemCoords( Edof, Coord, Dof )
%---------------------------------------------------------------------
% Puprose: Compute the element nodal coordinates
%---------------------------------------------------------------------
% Input: Edof   Topology matrix in terms of dof, 
%               size = NoElem x (NoElemDof+1)
%        Coord  Global nodal coordinates matrix, size = NoNodes x 2
%        Dof    Global nodal dof matrix, size = NoNodes x 2
%---------------------------------------------------------------------
% Output: Ex    Element nodal x-coordinates matrix
%         Ey    Element nodal y-coordanites matrix
%---------------------------------------------------------------------
% Created by: Dimosthenis Floros, 20180522
%---------------------------------------------------------------------

% Read number of finite elements

[ NoElem, NoCols ] = size( Edof );

% Read number of element dofs

NoElemDofs = NoCols - 1;

% Read number of dofs per node

NoDofsPerNode = size( Dof, 2 );

% Read number of element nodes

NoElemNodes = NoElemDofs/NoDofsPerNode;

% Compute topology matrix in terms of nodes

Enode = Edof( :, 3:2:end )/NoDofsPerNode;

% Compute Ex and Ey

Ex = zeros( NoElem, NoDofsPerNode );
Ey = Ex;

for elemIndex = 1:NoElem
   
    for nodeIndex = 1:NoElemNodes
        
        Ex( elemIndex, nodeIndex ) = ...
         Coord( Enode( elemIndex, nodeIndex ), 1 );
        Ey( elemIndex, nodeIndex ) = ...
         Coord( Enode( elemIndex, nodeIndex ), 2 );
        
    end
    
end

end

