function boundaryNodes = findGeneratedNodes( nodeSet )
% function boundaryNodes = findGeneratedNodes( nodeSet )
%---------------------------------------------------------------------
% Purpose: Generate the complete set of boundary nodes, based on given
%          start node label, end node label and step between the start 
%          and end node labels
%---------------------------------------------------------------------
% Input: nodeSet    nodeSet(1) --> step between start- and end-node 
%                                  labels
%                   nodeSet(2) --> start-node label
%                   nodeSet(3) --> end-node label
%---------------------------------------------------------------------
% Output: boundaryNodes  Generated/complete set of boundary nodes
%---------------------------------------------------------------------
% Created by: Dimosthenis Floros, 20170815
%---------------------------------------------------------------------

boundaryNodes = nodeSet(1):nodeSet(3):nodeSet(2);
boundaryNodes = boundaryNodes';

end

