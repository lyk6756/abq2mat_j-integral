function [ Edof, Dof, Coord, Ex, Ey, NoDofs, NoNodes, NoElem, Enode, ...
           boundarySet, existGen ] = abaqusMesh2Matlab( filename, ...
           elementType, boundaryNames )
% Call the function for mesh data extraction in one of the two following
% ways:

% 1) If extraction of boundary node sets is desired           

% function [ Edof, Dof, Coord, Ex, Ey, NoDofs, NoNodes, NoElem, Enode, ...
%            boundarySet, existGen ] = abaqusMesh2Matlab( filename, ...
%            elementType, boundaryNames )

% or

% 2) If extraction of boundary node sets is not required

% function [ Edof, Dof, Coord, Ex, Ey, NoDofs, NoNodes, NoElem, Enode ] = ...
%            abaqusMesh2Matlab( filename, elementType )

%-------------------------------------------------------------------------
% Purpose: Compute all the relevant FE matrices for the primary FE problem
%          from a given abaqus input file 
%-------------------------------------------------------------------------
% Input: filename       String with the path to abaqus .inp file
%        elementType    String that defines the type of finite element,
%                       supported types: 'linearTriangle' 
%                                        'quadraticTriangle'
%                                        'linearQuadrilateral'
%                                        'quadraticQuadrilateral'
%-------------------------------------------------------------------------
% Optional input:
%-------------------------------------------------------------------------
%        boundaryNames  Cell of strings with the names of the boundary 
%                       node sets that we want to extract, as they appear
%                       in abaqus .inp file
%-------------------------------------------------------------------------
% Output: Edof          Topology matrix i.t.o. dofs, 
%                       size = NoElem x ( NoElemDofs + 1 )
%         Dof           Global nodal dofs matrix, 
%                       size = NoNodes x NoDofPerNode
%         Coord         Nodal coordinates matrix, 
%                       size = NoNodes x 2
%         Ex, Ey        Element nodal coords matrices, 
%                       size = NoElem x NoElemNodes
%         NoDofs        Total number of dofs
%         NoNodes       Total number of nodes
%         NoElem        Total number of finite elements
%         Enode         Topology matrix i.t.o. nodes
%------------------------------------------------------------------------
% Optional outputs:
%------------------------------------------------------------------------
%         boundarySet   Cell structure with the boundary nodes for all the 
%                       specified boundaries
%         existGen      Vector with size equal to the number of node
%                       boundaries we want to extract from the .inp file.
%                       Each entry in existGen takes the value 1 if the 
%                       pertinent set of nodes is generated in abaqus and 
%                       the value 0 if the set is explicitly given in the 
%                       .inp file
%-------------------------------------------------------------------------
% Created by: Dimosthenis Floros, 20160615
%-------------------------------------------------------------------------

%% Process Abaqus text file

% Extract nodal coordinates matrix from abaqus input file

seekStringNodes = '*Node';

[ ~, NoLineNodes, NoNextNSetNodes ] = findLines( filename, ...
                                      seekStringNodes );

NodeSet = findNodes( filename, NoLineNodes, NoNextNSetNodes );

% Extract nodal connectivity matrix from abaqus input file

seekStringElement = '*Element';

[ ~, NoLineElement, NoNextNSetElement ] = findLines( filename, ...
                                          seekStringElement );

connectivity = findNodes( filename, NoLineElement, NoNextNSetElement);

%% Abaqus to FEM

% Extract number of nodes

NoNodes  = size( NodeSet, 1 );

% Extract problem dimensions, 2D or 3D

problemDim = size( NodeSet, 2 ) - 1;

% Extract nodal coordinates from set of nodes in the input file

Coord = NodeSet( :, 2:end );

% Extract number of finite elements from connectivity matrix 

NoElem = size( connectivity, 1 ); 

% Read number of element nodes and element dofs 

if strcmp( elementType, 'linearTriangle' ) == 1 

    NoElemNodes = 3;
    NoElemDofs  = 6;

elseif strcmp( elementType, 'quadraticTriangle' ) == 1   
 
     NoElemNodes = 6;
     NoElemDofs  = 12;
 
elseif strcmp( elementType, 'linearQuadrilateral' ) == 1
 
     NoElemNodes = 4;
     NoElemDofs  = 8;
 
elseif strcmp( elementType, 'quadraticQuadrilateral' ) == 1
 
     NoElemNodes = 8;
     NoElemDofs  = 16;
 
else 
    
    error( 'The elementType input is not correct' );
     
end
 
% Compute nodal dofs matrix

Dof = zeros( NoNodes,  problemDim );

for nodeIndex = 1:NoNodes
 
     Dof( nodeIndex, 1:problemDim ) =  ...
      ( nodeIndex - 1 )*problemDim + 1 : ...
      ( nodeIndex - 1 )*problemDim + problemDim;
 
end

% Compute topology matrix

Edof = zeros( NoElem, NoElemDofs + 1 );
Edof( :, 1 ) = linspace( 1, NoElem, NoElem )';

for elemIndex = 1:NoElem
 
 for nodeIndex = 1:NoElemNodes
 
     Edof( elemIndex, 2 + ( nodeIndex - 1 )*problemDim : ...
           1 + nodeIndex*problemDim ) = ...
      Dof( connectivity( elemIndex, nodeIndex + 1 ), : ); 
 
 end
 
end

% Compute total number of dofs

NoDofs = max( max( Dof ) );

% Compute topology matrix i.t.o. nodes

if strcmp( elementType, 'linearTriangle' ) == 1

    Enode  = Edof( :, [ 3 5 7 ] )/2;        

elseif strcmp( elementType, 'quadraticTriangle' ) == 1
 
    Enode = Edof( :, [ 3 5 7 9 11 13 ] )/2;
 
elseif strcmp( elementType, 'linearQuadrilateral' ) == 1
 
    Enode  = Edof( :, [ 3 5 7 9 ] )/2;
 
elseif strcmp( elementType, 'quadraticQuadrilateral' ) == 1
 
     Enode  = Edof( :, [ 3 5 7 9 11 13 15 17 ] )/2;
 
else
    
    error( 'The elementType input is not correct' );
 
end

% Compute element nodal x and y coordinates

[ Ex, Ey ] = extractElemCoords( Edof, Coord, Dof );

% If the number of input arguments is larger than 2 then compute outputs
% related to boundary node sets

if nargin > 2

    % Extract the boundary nodes vectors from abaqus input file

    NoBoundaries = size( boundaryNames, 1 );

    % Variable to store flag for whether the sought boundary node set is given
    % explicitly in the abaqus input file or if it needs to be generated

    existGen = zeros( NoBoundaries, 1 );

    % boundarySet = cell2struct( boundaryNames );

    for boundaryIndex = 1:NoBoundaries

        % Read name of the current boundary

         seekStringNodes = boundaryNames{ boundaryIndex, 1 };

        % Read lines where the sought boundary nodes set exists in the abaqus 
        % input file

        [ ~, NoLine, NoNextNSet, existGen( boundaryIndex ) ] = findLines( ...
          filename, seekStringNodes ); 

        % Read nodes of the current boundary from the lines in the abaqus input
        % file read above

        boundaryNodes = findSet(filename,NoLine,NoNextNSet);

        % If the node set is generated in Abaqus

        if existGen( boundaryIndex ) == 1

           boundaryNodes = findGeneratedNodes( boundaryNodes );

        end

        % Save nodes of the current boundary into a dynamically updated
        % cell structure

        boundarySet.(boundaryNames{boundaryIndex}) = boundaryNodes;

    end
    
end

% Delete temporary file created during text processing

folderPath = pwd;

tempTextFilePath = sprintf( '%s/Temporary.inp', folderPath ); 

delete( tempTextFilePath );

end

