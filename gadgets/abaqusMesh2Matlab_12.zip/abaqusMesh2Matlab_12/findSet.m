function [foundSet] = findSet( filename, NoLine, NoNextNSet )
% function [ foundSet ] = findSet( filename, NoLine, NoNextNSet )
%----------------------------------------------------------------
% [ NodeSet ] = findNodestest( filename, NoLine, NoNextNSet )
%----------------------------------------------------------------
% Purpose: Write located data set in a text in <matrix double>
%          form. This function is used instead of "findNodes",
%          when "dmlread" fails to read only numeric data, but 
%          it reads a structure instead.
%----------------------------------------------------------------
% Input: filename    Name of the text file
%        NoLine      Number of the line in filename that the 
%                    set sought for begins
%        NoNextSet   Number of the line in filename that the 
%                    next set after the one sought for begins
%----------------------------------------------------------------
% Output: foundSet    Vector containing the data set
%----------------------------------------------------------------
% Created by: Dimosthenis Floros, 20160816
%----------------------------------------------------------------

% Set counter of lines in the textfile that is being read

countLines = 1;

% Open the textfile with "read" permissions

fidIn = fopen( filename, 'r' );

% Create temporary text file to write the read data set in

temporaryFilename = 'Temporary.inp';

% Open the created temporary text file with "write" permissions

fidOut = fopen( temporaryFilename , 'w' );

% Read the textfile with "read" permissions line-by-line until
% the end-of-file has been reached

while ~feof( fidIn )
 
   % Read the current line string into currentLine variable

   currentLine = fgets( fidIn );

   % Check if the current line number lies between the line number
   % limits where the node-set sought for lies at. If the current line
   % lies within those line number limits, write the current line into
   % the temporary text file
   
   if countLines > NoLine && countLines < NoNextNSet 
    
      fprintf(fidOut,'%s \n',currentLine);
      
   end
   
   % Add one line number
  
   countLines = countLines + 1;
   
end

% Close both text files

fclose( fidIn );
fclose( fidOut );

% Read the data set written in the temporary text file into a variable
% in <matrix double> form

foundSetTemp = dlmread( temporaryFilename, ',' );

% Find exactly the data set sought for (which is a vector) from the 
% structure read by dlmread

[ ~, ~, v ] = find( foundSetTemp );

% Sort the data set vector 

%foundSet = sort( v );
foundSet = v;

if size( foundSet, 2 ) ~= 1

    foundSet = foundSet';
    
end

end
