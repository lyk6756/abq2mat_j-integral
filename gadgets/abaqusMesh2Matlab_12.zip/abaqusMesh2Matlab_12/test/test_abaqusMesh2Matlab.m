% Test file for function "AbaqusToFEMGeneral"
% Created by: Dimosthenis Floros

clearvars;
close all;

%% Restore default matlab path

restoredefaultpath;

%% The user should add his/her own path to folder which contains the 
%  provided "abaqusMesh2Matlab" functions into MATLAB search path

addpath( genpath( 'path2abaqusMesh2Matlab' ) );

%% Read name of abaqus .inp file (assuming that we are running the test 
%  file from subfolder "test")

filename = 'abaqusTestFile/testModel.inp';

%% Read cell that of strings that corresponds to all the boundary node sets
% we want to extract from the .inp file

boundaryNames = {'BOTTOMSIDENODES';
                 'TOPSIDENODES'};
        
%% Read finite element type             

elementType = 'linearTriangle';

%% Call function to extract the mesh details from Abaqus to MATLAB

[ Edof, Dof, Coord, Ex, Ey, NoDofs, NoNodes, NoElem, Enode, ...
  boundarySet, existGen ] = abaqusMesh2Matlab( filename, ...
  elementType, boundaryNames );

%% Assign the boundary node sets to distinct variables

bottomSideNodes = boundarySet.BOTTOMSIDENODES;
topSideNodes    = boundarySet.TOPSIDENODES;

%% Check of correctness of outputs 1
% The output of the "isequal" operation below should be 1

isequal( Enode*2, Edof( :, 3:2:end ) )

%% Plot the extracted mesh and check the figure with the abaqus mesh

figure;
hold on;
for elemIndex = 1:NoElem
   
    plot( [ Ex( elemIndex, : ) Ex( elemIndex, 1 ) ], ...
          [ Ey( elemIndex, : ) Ey( elemIndex, 1 ) ], '-k.' );
    
end
hold off;
